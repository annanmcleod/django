class Glass:
    def __init__(self, capacity):
        raise NotImplementedError

    def pour_in(self, amount):
        raise NotImplementedError

    def pour_out(self, amount):
        raise NotImplementedError
